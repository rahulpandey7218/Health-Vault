import { initializeApp } from "firebase/app"
import { getAuth } from "firebase/auth"
import { getFirestore } from "firebase/firestore"
import { getAnalytics } from "firebase/analytics"

const firebaseConfig = {
  apiKey: "AIzaSyCwzo81MeRJcBkki11Pn2V6Up8jvTtbfbo",
  authDomain: "health--vault.firebaseapp.com",
  projectId: "health--vault",
  storageBucket: "health--vault.firebasestorage.app",
  messagingSenderId: "25091872315",
  appId: "1:25091872315:web:f700ae0e2cfde4f054ae1e",
  measurementId: "G-778YDNNX5M",
}

// Initialize Firebase
const app = initializeApp(firebaseConfig)

// Initialize Firebase Authentication and get a reference to the service
export const auth = getAuth(app)

// Initialize Cloud Firestore and get a reference to the service
export const db = getFirestore(app)

// Initialize Analytics (only in browser)
let analytics
if (typeof window !== "undefined") {
  analytics = getAnalytics(app)
}

export { analytics }
export default app
